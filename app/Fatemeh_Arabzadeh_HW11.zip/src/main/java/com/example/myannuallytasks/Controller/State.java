package com.example.myannuallytasks.Controller;

public enum State {
    TODO, DOING, DONE,
}
